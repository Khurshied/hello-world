## **This is a template for a microservice visual studio solution**

How to use:

 1. Clone the repository to your local machine
 2. Copy the content it to your project folder
 3. Run setup.bat and enter your project name (e. g. ATLP) and module name (e. g. ServiceManagement)

Once the setup is done, the CMD window will close automatically and delete the extra files.
