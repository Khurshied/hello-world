﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using AutoMapper;
using MG;
using MassTransit;
using MassTransit.ExtensionsDependencyInjectionIntegration;
using MG.__MODULENAME__.Registration.SQL.Data;
using MG.__PROJECTNAME__.__MODULENAME__.Domain;
using MG.__PROJECTNAME__.__MODULENAME__.Domain.AutoMapper;
using MG.__PROJECTNAME__.__MODULENAME__.Domain.ConfigOptions;
using MG.__PROJECTNAME__.__MODULENAME__.SQL.Data;
using MG.AspNetCore.Filter;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Serilog;
using UserSession = MG.AspNetCore.Auth.UserSession;

namespace MG.__PROJECTNAME__.__MODULENAME__.API.DependencyConfig
{
    public static class DependencyConfig
    {
        public static void AddHttpClients(this IServiceCollection services,IConfiguration configuration)
        {
            
        }
        public static void AddRepositories(this IServiceCollection services)
        {
            //services.AddScoped<IBillingRepository, BillingRepository>();

            var types = Assembly.Load(new AssemblyName("MG.__PROJECTNAME__.__MODULENAME__.SQL.Infrastructure"))
                                .DefinedTypes
                                .ToList();
            //Key: Repository interface
            //Value: Repository implementation
            var repos = new Dictionary<Type, Type>();
            foreach (var typeInfo in types)
            {
                var repoInterface = typeInfo.ImplementedInterfaces.FirstOrDefault(e => e.GetInterfaces().Any(i => i.IsGenericType && i.GetGenericTypeDefinition() == typeof(IRepository<>)));
                if (repoInterface == null)
                    continue;

                repos.Add(repoInterface, typeInfo);
            }

            foreach (var repo in repos)
            {
                services.AddScoped(repo.Key, repo.Value);
            }
        }

        public static void AddDataServices(this IServiceCollection services)
        {
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            services.AddScoped(typeof(IUnitOfWork), typeof(UnitOfWork));

            services.AddScoped<IUserSession, UserSession>();
        }

        public static void AddOptionsBinders(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddOptions<RecaptchaOption>().Bind(configuration.GetSection(RecaptchaOption.SectionName)).ValidateDataAnnotations();
            services.AddOptions<FileSizeLimitOption>().Bind(configuration.GetSection(FileSizeLimitOption.SectionName)).ValidateDataAnnotations();
        }

        public static void AddDbContext(this IServiceCollection services, IConfiguration configuration, IHostEnvironment env)
        {
            var connectionString = configuration.GetConnectionString("DB");
            services.AddDbContext<__MODULENAME__DbContext>(options =>
            {
                options.EnableSensitiveDataLogging();
                options.UseSqlServer(connectionString, sqlServerOptions => sqlServerOptions.CommandTimeout(90));
            });
        }

        public static void AddDapper(this IServiceCollection services, IConfiguration configuration, IHostEnvironment env)
        {
            var connectionString = configuration.GetConnectionString("DB");

            Dapper.DefaultTypeMap.MatchNamesWithUnderscores = true;

            services.AddTransient<IDbConnection>(c => new SqlConnection(connectionString));
        }

        public static void AddSwagger(this IServiceCollection services)
        {
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1",
                             new OpenApiInfo
                             {
                                 Version = "2.0",
                                 Title = "AD Maritime API",
                                 Description = "AD Maritime service",
                             });

                c.AddSecurityDefinition("Bearer",
                                        new OpenApiSecurityScheme
                                        {
                                            In = ParameterLocation.Header,
                                            Description = "Please enter into field the word 'Bearer' following by space and JWT",
                                            Name = "Authorization",
                                            Type = SecuritySchemeType.ApiKey
                                        });

                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {new OpenApiSecurityScheme
                    {
                        In = ParameterLocation.Header,
                        Description = "Please enter into field the word 'Bearer' following by space and JWT",
                        Name = "Authorization",
                        Type = SecuritySchemeType.ApiKey
                    },Enumerable.Empty<string>().ToList()},
                });
            });
        }

        public static void AddAuth(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSingleton(new HasPermissionFilterOptions("__MODULENAME__", ""));
            var audienceConfig = configuration.GetSection("Audience");
            var signingKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(audienceConfig["Secret"]));
            var tokenValidationParameters = new TokenValidationParameters
            {
                NameClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier",
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = signingKey,
                ValidateIssuer = true,
                ValidIssuer = audienceConfig["Iss"],
                ValidateAudience = true,
                ValidAudience = audienceConfig["Aud"],
                ValidateLifetime = true,
                ClockSkew = TimeSpan.Zero,
                RequireExpirationTime = true
            };

            services.AddAuthentication(options =>
                    {
                        options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                        options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                    })
                    .AddJwtBearer(x =>
                    {
                        x.RequireHttpsMetadata = false;
                        x.TokenValidationParameters = tokenValidationParameters;
                    });
        }

        public static void AddLogs(this IServiceCollection services, IConfiguration configurations)
        {
            Log.Logger = new LoggerConfiguration()
                         .ReadFrom.Configuration(configurations)
                         .CreateLogger();
        }

        public static void AddServiceBus(this IServiceCollection services,
                                         IConfiguration configurations,
                                         IHostEnvironment hostEnvironment,
                                         Action<IServiceCollectionConfigurator> registerAdditionalConsumers)
        {

            Log.Information("Configuring RabbitMQ");

            var massTransitConfig = configurations.GetSection("MassTransit");
            var _protocol = massTransitConfig["Protocol"];
            var _rabbitMQHost = massTransitConfig["ClusterUrl"];
            var _rabbitMQUserName = massTransitConfig["UserName"];
            var _rabbitMQPassword = massTransitConfig["Password"];
            var nodes = massTransitConfig.GetSection("Nodes").Get<string[]>();
            services.AddMassTransit(x =>
            {
                //x.AddConsumer<BillingLineHandler>();
                x.AddBus(provider => Bus.Factory.CreateUsingRabbitMq(cfg =>
                {
                    var host = cfg.Host(new Uri($"{_protocol}://{_rabbitMQHost}"),
                                        hostConfig =>
                                        {
                                            hostConfig.Username(_rabbitMQUserName);
                                            hostConfig.Password(_rabbitMQPassword);
                                            if (nodes != null && nodes.Any())
                                                hostConfig.UseCluster(e =>
                                                {
                                                    foreach (var node in nodes)
                                                    {
                                                        e.Node(node);
                                                    }
                                                });
                                        });

                services.AddSingleton(c => host);
                }));
            });

            // Start Service Bus
            var busControl = services.BuildServiceProvider()
                                     .GetService<IBusControl>();

            busControl.Start();
        }

        public static void AddMapper(this IServiceCollection services)
        {
            services.AddAutoMapper(typeof(EntityToDtoMappings));
        }

        public static void AddCoresAllowAll(this IServiceCollection services)
        {
            services.AddCors(c =>
            {
                c.AddPolicy("AllowAllOrigin",
                            options => options.AllowAnyOrigin()
                                              .AllowAnyMethod()
                                              .AllowAnyHeader());
            });
        }
    }
}