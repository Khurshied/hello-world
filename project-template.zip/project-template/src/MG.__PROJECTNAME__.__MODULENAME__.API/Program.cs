﻿using MG.__PROJECTNAME__.__MODULENAME__.API;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;

namespace MG.__PROJECTNAME__.__MODULENAME__.API
{
    public class Program
    {
        public static void Main(string[] args)
        {
            
            CreateWebHostBuilder(args).Build().Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args)
        {
            return WebHost.CreateDefaultBuilder(args)
                          .UseStartup<Startup>();
        }
    }
}