﻿using AutoMapper;

namespace MG.__PROJECTNAME__.__MODULENAME__.Domain.AutoMapper
{
   
    public class EntityToDtoMappings : Profile
    {
        public EntityToDtoMappings()
        {
      
        }
    }

}