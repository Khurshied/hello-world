﻿namespace MG.__PROJECTNAME__.__MODULENAME__.Domain.Enums
{
   
}