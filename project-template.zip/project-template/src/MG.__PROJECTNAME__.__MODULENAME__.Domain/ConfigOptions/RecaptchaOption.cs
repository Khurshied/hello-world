﻿using System.ComponentModel.DataAnnotations;

namespace MG.__PROJECTNAME__.__MODULENAME__.Domain.ConfigOptions
{
    public class RecaptchaOption
    {
        public const string SectionName = "ReCaptchaVerification";

        [Required]
        public bool Enabled { get; set; }
        [Required]
        public bool Bypass { get; set; }
        [Required]
        public string VerificationUrl { get; set; }
        [Required]
        public string SecretKey { get; set; }
    }
}
