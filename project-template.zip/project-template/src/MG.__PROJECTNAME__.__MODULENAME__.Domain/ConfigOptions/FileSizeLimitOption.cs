﻿using System.ComponentModel.DataAnnotations;

namespace MG.__PROJECTNAME__.__MODULENAME__.Domain.ConfigOptions
{
    public class FileSizeLimitOption
    {
        public const string SectionName = "FileSizeUploadLimnit";

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "FileSizeUploadLimnit config: Value for {0} must be between {1} and {2}.")]
        public int MinimumFileSizeInBytes { get; set; }
        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "FileSizeUploadLimnit config: Value for {0} must be between {1} and {2}.")]
        public int MaximumFileSizeInBytes { get; set; }
    }
}
