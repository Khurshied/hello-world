﻿namespace MG.ADMaritime
{
    public class OTPMessage : IMessage
    {
        public string OTPCode { get; set; }
        public string MobileNumber { get; set; }

    }
}
