﻿namespace MG.ADMaritime
{
    public class UserRegistered: IMessage
    {
        public string FullName { get; set; }
        public string Email { get; set; }
        public string MobileNumber { get; set; }
        public string UserType { get; set; }
        public string LanguagePreference { get; set; }
    }
}
