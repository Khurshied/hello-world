﻿namespace MG.ADMaritime
{
    //Marker interface
    public interface IMessage
    {
    }
}
