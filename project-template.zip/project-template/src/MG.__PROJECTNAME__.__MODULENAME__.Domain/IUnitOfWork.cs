﻿using System.Threading.Tasks;

namespace MG.__PROJECTNAME__.__MODULENAME__.SQL.Data
{
    public interface IUnitOfWork
    {
        int Commit();
        Task<int> CommitAsync();
    }
}