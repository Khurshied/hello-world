﻿using System;

namespace MG.__PROJECTNAME__.__MODULENAME__.Domain
{
    public class EntityBase
    {
        public virtual string Id { get; set; }
        
        public virtual DateTime CreatedDate { get; set; }
        public virtual string CreatedBy { get; set; }

        public virtual DateTime? UpdatedDate { get; set; }
        public virtual string UpdatedBy { get; set; }
    }
}