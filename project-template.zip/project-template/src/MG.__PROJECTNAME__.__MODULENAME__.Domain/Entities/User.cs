﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace MG.__PROJECTNAME__.__MODULENAME__.Domain.Entities
{
    [Table("USER")]
    public class User:EntityBase
    {

        public User()
        {
            UserDocuments = new HashSet<UserDocument>();
            UserMetaDatas = new HashSet<UserMetaData>();

        }
        [Column("EMAIL")]
        public string Email { get; set; }

        [Column("FULL_NAME")]
        public string FullName { get; set; }

        [Column("MOBILE_NUMBER")]
        public string MobileNumber { get; set; }

        [Column("AREAID")]
        public string AreaId { get; set; }

        [Column("POBOX")]
        public string POBox { get; set; }

        [Column("ADDRESS")]
        public string Address { get; set; }

        [Column("LANGUAGE_PREFERENCE")]
        public string LanguagePreference { get; set; } = "en";

        [Column("LOOKUPTYPEID")]
        public string LookupTypeId { get; set; }

        [ForeignKey("LookupTypeId")]
        public virtual Lookup Lookup { get; set; }

        public virtual ICollection<UserDocument> UserDocuments { get; set; }
        public virtual ICollection<UserMetaData> UserMetaDatas { get; set; }
    }
}