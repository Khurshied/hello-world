﻿using System.ComponentModel.DataAnnotations.Schema;

namespace MG.__PROJECTNAME__.__MODULENAME__.Domain.Entities
{
    [Table("SMSCODE")]
    public class SMSCode:EntityBase
    {
        [Column("SMS_CODE")]
        public string Code { get; set; }

        [Column("MOBILE")]
        public string Mobile { get; set; }

        [Column("ISACTIVE")]
        public bool IsActive { get; set; } = true;
    }
}