﻿using System.ComponentModel.DataAnnotations.Schema;

namespace MG.__PROJECTNAME__.__MODULENAME__.Domain.Entities
{
    public class Category:EntityBase
    {
        [Column("NAME")]
        public string Name { get; set; }

        [Column("PARENT_ID")]
        public string ParentId { get; set; }
    }
}