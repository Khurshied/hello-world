﻿using System.ComponentModel.DataAnnotations.Schema;

namespace MG.__PROJECTNAME__.__MODULENAME__.Domain.Entities
{
    [Table("USERDOCUMENT")]
    public class UserDocument:EntityBase
    {
        [Column("USERID")]
        public string UserId { get; set; }

        [Column("CONTENT_TYPE")]
        public string ContentType { get; set; }

        [Column("FILE_NAME")]
        public string FileName { get; set; }

        [Column("FILE_BYTES")]
        public byte[] FileBytes { get; set; }

        [Column("LOOKUP_TYPEID")]
        public string LookupTypeId { get; set; }


        [ForeignKey("LookupTypeId")]
        public virtual Lookup Lookup { get; set; }


        [ForeignKey("UserId")]
        public virtual User User{ get; set; }

    }
}