﻿using System.ComponentModel.DataAnnotations.Schema;

namespace MG.__PROJECTNAME__.__MODULENAME__.Domain.Entities
{
    [Table("USERMETADATA")]
    public class UserMetaData:EntityBase
    {
        [Column("USERID")]
        public string UserId { get; set; }

        [Column("METATYPE")]
        public string MetaType { get; set; }

        [Column("METADATA")]
        public string MetaData { get; set; }

        [ForeignKey("UserId")]
        public virtual User User { get; set; }

    }
}