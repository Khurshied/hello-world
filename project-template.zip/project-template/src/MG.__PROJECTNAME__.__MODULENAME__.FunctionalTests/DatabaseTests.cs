﻿using MG.SvcManagement.API.FunctionalTests;
using Xunit;

namespace MG.__PROJECTNAME__.__MODULENAME__.FunctionalTests
{
    [Collection(TestCollections.DatabaseCollection)]
    public class DatabaseTests : ICollectionFixture<DatabaseFixture>
    {
    }
}