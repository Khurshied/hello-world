﻿using MG.__PROJECTNAME__.__MODULENAME__.Client;

namespace MG.SvcManagement.API.FunctionalTests
{
    public class TestBase : Client
    {


    }
}