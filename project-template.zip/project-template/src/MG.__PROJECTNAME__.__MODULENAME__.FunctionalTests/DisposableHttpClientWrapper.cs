﻿using System;
using System.Net.Http;
using Microsoft.AspNetCore.TestHost;

namespace MG.SvcManagement.API.FunctionalTests
{
    /// <summary>
    ///     A wrapper object for the test server and client
    /// </summary>
    public class DisposableHttpClientWrapper : IDisposable
    {
        public DisposableHttpClientWrapper(TestServer server)
        {
            Server = server;
            Client = server.CreateClient();
        }

        public HttpClient Client { get; }
        public TestServer Server { get; }

        public void Dispose()
        {
            Client.Dispose();
            Server.Dispose();
        }
    }
}