﻿namespace MG.SvcManagement.API.FunctionalTests
{
    public static class TestCollections
    {
        public const string DatabaseCollection = nameof(DatabaseCollection);
    }
}