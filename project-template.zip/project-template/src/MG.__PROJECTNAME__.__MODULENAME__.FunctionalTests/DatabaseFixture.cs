﻿using System;
using MG.__MODULENAME__.Registration.SQL.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json;
using Microsoft.Extensions.FileProviders;

namespace MG.SvcManagement.API.FunctionalTests
{
    public class DatabaseFixture : IDisposable
    {
        public DatabaseFixture()
        {
            var file = new JsonConfigurationSource
            {
#if DEBUG
                Path = "appsettings.Testing.json",
#else
                Path = "appsettings.json",
#endif
                FileProvider = new PhysicalFileProvider(AppDomain.CurrentDomain.BaseDirectory),
                Optional = false
            };
            var builder = new ConfigurationBuilder();
            builder.Add(file);
            var config = builder.Build();
            var connection = config["ConnectionStrings:DBConnection"];
            var contextOptions = new DbContextOptionsBuilder<__MODULENAME__DbContext>();
            contextOptions.UseSqlServer(connection);
            DbContext = new __MODULENAME__DbContext(contextOptions.Options);
            SeedTestData(true);
        }

        public __MODULENAME__DbContext DbContext { get; }

        public void Dispose()
        {
            DbContext.Dispose();
        }

        public void SeedTestData(bool clearOldData = false)
        {
        }
    }
}