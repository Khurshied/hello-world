﻿namespace MG.__PROJECTNAME__.__MODULENAME__.FunctionalTests
{
    public class PayloadFiles
    {
        public const string CreateIndividualUser = nameof(CreateIndividualUser);
    }
}