﻿namespace MG.__PROJECTNAME__.__MODULENAME__.FunctionalTests
{
    public static class Scripts
    {
        public const string ClearDB = nameof(ClearDB);
        public const string SeedData = nameof(SeedData);
    }
}