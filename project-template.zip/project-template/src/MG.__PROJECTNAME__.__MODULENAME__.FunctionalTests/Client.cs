﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using MG;
using MG.__PROJECTNAME__.__MODULENAME__.Registration;
using Newtonsoft.Json.Linq;

namespace MG.__PROJECTNAME__.__MODULENAME__.Client
{
    public class Client
    {
        protected Payload GetPayload(string payloadName)
        {
            return GetPayload(payloadName,
                              new Dictionary<string, string>
                              {
                                  {"RotationNumber", GetRandomRotationNumber()}
                              });
        }

        /// <summary>
        ///     Returns the content of multiple payloads using a search pattern.
        ///     AJ.
        /// </summary>
        protected IEnumerable<Payload> GetPayloads(string searchPattern, Dictionary<string, string> values)
        {
            var directory = new DirectoryInfo(Path.Combine(Directory.GetCurrentDirectory(), "Payloads"));
            var files = directory.GetFiles(searchPattern);
            return files.Select(e => GetPayloadByFile(e, values));
        }

        /// <summary>
        ///     Returns the content of a json file from the Payloads folder in the project directory.
        ///     AJ.
        /// </summary>
        protected Payload GetPayload(string payloadName, Dictionary<string, string> values = null)
        {
            return GetPayloadByFile(new FileInfo(Path.Combine(Directory.GetCurrentDirectory(), "Payloads", $"{payloadName}.json")), values);
        }

        /// <summary>
        ///     Returns the content of a json file from the Payloads folder in the project directory.
        ///     AJ.
        /// </summary>
        protected Payload GetPayloadByFile(FileInfo file, Dictionary<string, string> values)
        {
            var content = File.ReadAllText(file.FullName);

            if (values != null)
                foreach (var item in values)
                    content = content.Replace($"%{item.Key}%", item.Value);

            return new Payload(file.Name,
                               file.FullName,
                               content);
        }

        protected Payload GetPayload(string payloadName, string rotationNumber)
        {
            return GetPayload(payloadName,
                              new Dictionary<string, string>
                              {
                                  {"RotationNumber", rotationNumber}
                              });
        }

        public string GenerateRandomNumbersString(int min =70008000,int max =80000000)
        {
            var rand = new Random(DateTime.Now.Millisecond * DateTime.Now.Second);
            var number = rand.Next(min,max);
            return number.ToString();
        }

        /// <summary>
        ///     Ensures the response status code is OK and the <see cref="ServiceResponse.success" /> is true
        ///     AJ.
        /// </summary>
        /// <returns>The <see cref="ServiceResponse.data" /> as a <see cref="JObject" /></returns>
        protected virtual async Task<TData> ValidateResponseSuccess<TData>(HttpResponseMessage response) where TData : JToken
        {
            if (!response.IsSuccessStatusCode)
            {
                var exPlainResponse = await response.Content.ReadAsStringAsync();

                string message = null;
                if (!string.IsNullOrWhiteSpace(exPlainResponse))
                {
                    var exResult = JObject.Parse(exPlainResponse);
                    message = exResult.GetValue("msg").Value<string>();
                }

                throw new HttpRequestException($"Response returned error code {response.StatusCode}.{Environment.NewLine}Response content:{message}");
            }

            var plainResponse = await response.Content.ReadAsStringAsync();
            var jResult = JObject.Parse(plainResponse);
            jResult.TryGetValue("success", out var success);
            jResult.TryGetValue("data", out var dataToken);
            if (dataToken.HasValues)
            {
                var jData = (TData)dataToken;
                return jData;
            }

            return null;
        }

        /// <summary>
        ///     Ensures the response status code is OK and the <see cref="ServiceResponse.success" /> is true
        ///     AJ.
        /// </summary>
        /// <returns>The <see cref="ServiceResponse.data" /> as a <see cref="JObject" /></returns>
        protected Task<JObject> ValidateResponseSuccess(HttpResponseMessage response)
        {
            return ValidateResponseSuccess<JObject>(response);
        }

        public string GetRandomRotationNumber()
        {
            var rand = new Random();
            var number = rand.Next(80000000, 90000000);
            return number.ToString();
        }

        /// <summary>
        ///     Parses a object and calls the assert function with the object value.
        ///     AJ.
        /// </summary>
        protected T GetProperty<T>(JObject jData, string property)
        {
            jData.TryGetValue(property, StringComparison.InvariantCultureIgnoreCase, out var token);
            var value = token.Value<T>();
            return value;
        }

        /// <summary>
        ///     Parses a object and calls the validate function with the object value.
        ///     AJ.
        /// </summary>
        protected T GetProperty<T>(JObject jData, string property, Func<T, bool> validate)
        {
            jData.TryGetValue(property, StringComparison.InvariantCultureIgnoreCase, out var token);
            var value = token.Value<T>();
            return value;
        }

        /// <summary>
        ///     Parses a guid object and validates that it matches the criteria
        ///     AJ.
        /// </summary>
        protected Guid GetGuidProperty(JObject jData, string property, Guid? expectedValue = null)
        {
            var value = GetProperty<string>(jData, property, e => !string.IsNullOrWhiteSpace(e));
            Guid.TryParse(value, out var guid);
            return guid;
        }

        /// <summary>
        ///     Gets a string value from json and checks that it's not null
        ///     AJ.
        /// </summary>
        protected string GetStringProperty(JObject jData, string property, string expectedValue = null)
        {
            var res = GetProperty<string>(jData, property, e => !string.IsNullOrWhiteSpace(e));
            return res;
        }
    }
}