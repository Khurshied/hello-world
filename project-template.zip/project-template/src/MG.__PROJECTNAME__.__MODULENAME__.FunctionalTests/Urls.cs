﻿namespace MG.__PROJECTNAME__.__MODULENAME__.FunctionalTests
{
    public static class Urls
    {
        public static string CreateIndividualUser() => "/api/Registration/individual";
    }
}