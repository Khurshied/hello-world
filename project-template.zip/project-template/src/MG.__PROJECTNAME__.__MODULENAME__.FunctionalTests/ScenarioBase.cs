﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using MG;
using MG.__MODULENAME__.Registration.SQL.Data;
using MG.__PROJECTNAME__.__MODULENAME__.FunctionalTests;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using Xunit;
using Xunit.Abstractions;

namespace MG.SvcManagement.API.FunctionalTests
{
    /// <summary>
    ///     The base class for the functional and integrations tests.
    ///     AJ.
    /// </summary>
    public class ScenarioBase : TestBase
    {
        protected const string _authUrl = "http://10.0.131.21/MG/corecomponent/basegateway/login";
        protected static string _token;
        protected static object _tokenLock = new object();
        protected static IConfiguration _configuration;
        protected static string _connectionString;
        protected List<string> _createdTestServices;
        protected IServiceProvider _serviceProvider;

        public ScenarioBase(ITestOutputHelper outputHelper)
        {
            Output = outputHelper;
            _createdTestServices = new List<string>();
        }

        protected ITestOutputHelper Output { get; }
        protected ILogger<ScenarioBase> Logger { get; private set; }

        /// <summary>
        ///     Creates and setup a test server instance.
        ///     AJ.
        /// </summary>
        protected TestServer CreateServer(bool clearDb = true)
        {
            TestStartup.Output = Output;

            var builder = new WebHostBuilder()
                          .UseEnvironment("Testing")
                          .ConfigureAppConfiguration(config =>
                          {
#if DEBUG
                              config.AddJsonFile("appsettings.Development.json", false).AddEnvironmentVariables();
                              config.AddJsonFile("appsettings.Testing.json", false).AddEnvironmentVariables();
#else
                              config.AddJsonFile("appsettings.json", optional: false).AddEnvironmentVariables();
#endif
                          })
                          .UseStartup<TestStartup>();

            var server = new TestServer(builder);
            _serviceProvider = server.Host.Services;
            Logger = _serviceProvider.GetRequiredService<ILogger<ScenarioBase>>();
            if (_configuration == null)
            {
                _configuration = _serviceProvider.GetService<IConfiguration>();
                _connectionString = _configuration.GetConnectionString("ADMTServiceDB");
                _token = _configuration["Token"];
            }

            if (clearDb)
            {
                ExecuteDbScript(Scripts.ClearDB);
                ExecuteDbScript(Scripts.SeedData);
            }
            return server;
        }

        protected T GetService<T>(TestServer server)
        {
            return server.Host.Services.GetRequiredService<T>();
        }

        protected IServiceScope CreateScope(TestServer server)
        {
            return server.Host.Services.CreateScope();
        }

        /// <inhertdoc cref="CreateClient()" />
        protected DisposableHttpClientWrapper CreateClient(TestServer server)
        {
            var wrapper = new DisposableHttpClientWrapper(server);
            var client = wrapper.Client;
            SetToken(client);
            return wrapper;
        }

        /// <summary>
        ///     Creates a disposable wrapper for a test server and an HTTP client.
        ///     AJ.
        /// </summary>
        protected DisposableHttpClientWrapper CreateClient(bool clearDb=true)
        {
            return CreateClient(CreateServer(clearDb));
        }
        
        protected static Random Random { get; set; } = new Random(DateTime.Now.Millisecond);
         protected string GenerateRandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
                                        .Select(s => s[Random.Next(s.Length)]).ToArray());
        }
        
        /// <summary>
        ///     Sends an authentication request to the IdentityServer and sets the token in the http client.
        ///     AJ.
        /// </summary>
        protected void SetToken(HttpClient client)
        {
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _token);
        }

       
        protected void ExecuteDbScript(string script, Dictionary<string, string> values = null)
        {
            DbContextExecute(db => { db.Database.ExecuteSqlRaw(GetScript(script, values)); });
        }


        /// <summary>
        ///     Ensures the response status code is OK and the <see cref="ServiceResponse.success" /> is true
        ///     AJ.
        /// </summary>
        /// <returns>The <see cref="ServiceResponse.data" /> as a <see cref="JObject" /></returns>
        protected override async Task<TData> ValidateResponseSuccess<TData>(HttpResponseMessage response)
        {
            if (!response.IsSuccessStatusCode)
            {
                var exPlainResponse = await response.Content.ReadAsStringAsync();
                Output.WriteLine($"API response for {response.RequestMessage.RequestUri} is {exPlainResponse}");
                string message = null;
                if (!string.IsNullOrWhiteSpace(exPlainResponse))
                {
                    var exResult = JObject.Parse(exPlainResponse);
                    message = exResult.GetValue("msg").Value<string>();
                }

                throw new HttpRequestException($"Response returned error code {response.StatusCode}.{Environment.NewLine}Response content:{message}");
            }

            var plainResponse = await response.Content.ReadAsStringAsync();
            var jResult = JObject.Parse(plainResponse);
            Assert.True(jResult.TryGetValue("success", out var success) && success.Value<bool>());
            Assert.True(jResult.TryGetValue("data", out var dataToken));
            if (dataToken.HasValues)
            {
                var jData = (TData)dataToken;
                return jData;
            }

            return null;
        }
        protected void DbContextExecute(Action<__MODULENAME__DbContext> action)
        {
            var dbContext = CreateDbContext();
            using (dbContext)
            {
                action(dbContext);
            }
        }

        protected TResult DbContextExecute<TResult>(Func<__MODULENAME__DbContext, TResult> func)
        {
            var dbContext = CreateDbContext();
            using (dbContext)
            {
                return func(dbContext);
            }
        }

        protected __MODULENAME__DbContext CreateDbContext()
        {
            var builder = new DbContextOptionsBuilder<__MODULENAME__DbContext>();
            builder.UseSqlServer(_connectionString);
            var serviceDbContext = new __MODULENAME__DbContext(builder.Options);
            return serviceDbContext;
        }

     

        protected async Task Retry(int retryCount, TimeSpan retryDelay, Action action)
        {
            var tryCount = 0;
            while (tryCount <= retryCount)
                try
                {
                    action();
                    break;
                }
                catch (Exception)
                {
                    tryCount++;
                    if (tryCount == retryCount)
                        throw;
                    await Task.Delay(retryDelay);
                }
        }

        protected async Task Retry(int retryCount, TimeSpan retryDelay, TimeSpan initialDelay, Action action)
        {
            await Task.Delay(initialDelay);
            await Retry(retryCount, retryDelay, action);
        }

        public async Task Retry(TimeSpan initialDelay, Action action)
        {
            await Retry(4, TimeSpan.FromSeconds(10), initialDelay, action);
        }

        public async Task Retry(int retryCount, Action action)
        {
            await Retry(retryCount, TimeSpan.FromSeconds(10), TimeSpan.FromSeconds(20), action);
        }

        protected async Task Retry(Action action)
        {
            await Retry(3, TimeSpan.FromSeconds(10), TimeSpan.FromSeconds(15), action);
        }

        protected string GetScript(string scriptName, Dictionary<string, string> values = null)
        {
            var file = new FileInfo(Path.Combine(Directory.GetCurrentDirectory(), "Scripts", $"{scriptName}.sql"));
            var content = File.ReadAllText(file.FullName);
            if (values != null)
                foreach (var item in values)
                    content = content.Replace($"%{item.Key}%", item.Value);

            return content;
        }
    }
}