﻿using MG.__PROJECTNAME__.__MODULENAME__.API;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Xunit.Abstractions;

namespace MG.__PROJECTNAME__.__MODULENAME__.FunctionalTests
{
    public class TestStartup : Startup
    {
        public TestStartup(IConfiguration configuration, IHostEnvironment hostingEnvironment) : base(configuration, hostingEnvironment)
        {
            
        }

        public override void ConfigureServices(IServiceCollection services)
        {
            base.ConfigureServices(services);
        }

        public static ITestOutputHelper Output { get; set; }
    }
}