﻿using System.Net.Http;
using System.Text;

namespace MG.__PROJECTNAME__.__MODULENAME__.Registration
{
    public class Payload
    {
        public Payload()
        {
        }

        public Payload(string title, string file, string content)
        {
            Title = title;
            File = file;
            SetContent(content);
        }

        public string Title { get; set; }
        public string File { get; set; }
        public StringContent Content { get; set; }
        public string RawContent { get; set; }

        public void SetContent(string newContent)
        {
            RawContent = newContent;
            Content = new StringContent(RawContent,
                                        Encoding.UTF8,
                                        "application/json");
        }
    }
}