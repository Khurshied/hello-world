﻿using System;
using MG.__PROJECTNAME__.__MODULENAME__.Domain;
using MG.__PROJECTNAME__.__MODULENAME__.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace MG.__MODULENAME__.Registration.SQL.Data
{
    public class __MODULENAME__DbContext : DbContext
    {
        public __MODULENAME__DbContext(DbContextOptions<__MODULENAME__DbContext> options) : base(options)
        {
        }

        




        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            foreach (var entityType in modelBuilder.Model.GetEntityTypes())
                if (entityType.ClrType.IsSubclassOf(typeof(EntityBase)))
                    SetTrackingColumnsMapping(modelBuilder, entityType.ClrType);
            
            base.OnModelCreating(modelBuilder);
        }

        /// <summary>
        ///     Sets the CreatedDate, update changes mapping
        /// </summary>
        private void SetTrackingColumnsMapping(ModelBuilder modelBuilder, Type entityType)
        {
            modelBuilder.Entity(entityType).Property(nameof(EntityBase.Id)).HasColumnName("ID").ValueGeneratedOnAdd();
            modelBuilder.Entity(entityType).Property(nameof(EntityBase.CreatedDate)).HasColumnName("CREATED_DATE");
            modelBuilder.Entity(entityType).Property(nameof(EntityBase.CreatedBy)).HasColumnName("CREATEDBY");
            modelBuilder.Entity(entityType).Property(nameof(EntityBase.UpdatedBy)).HasColumnName("UPDATEDBY");
            modelBuilder.Entity(entityType).Property(nameof(EntityBase.UpdatedDate)).HasColumnName("UPDATED_DATE");
        }
    }
}