﻿using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
using MG;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json.Linq;

namespace MG.__PROJECTNAME__.__MODULENAME__.Services
{
    public class UserSession : IUserSession
    {
        private readonly HttpContext _context;

        private static string _serviceCode;
        private static string _authURL;


        public UserSession(IHttpContextAccessor context)
        {
            _context = context.HttpContext;
        }

        public User GetUser()
        {
            var identity = _context?.User?.Identity as ClaimsIdentity;
            User user = null;

            if (identity?.Claims != null && identity.Claims.Any() && !string.IsNullOrEmpty(identity.Name))
            {
                var userGroups = identity.Claims.FirstOrDefault(x => x.Type == "USERGROUP");
                user = new User
                {
                    Name = identity.Name,
                    UserGroups = userGroups?.Value.Split(',')
                };
            }

            return user;
        }

        public bool HasPermission(string process, string subProcess)
        {
            if (string.IsNullOrEmpty(_serviceCode))
            {
                var config = _context.RequestServices.GetRequiredService<IConfiguration>();
                _serviceCode = config["ServiceOptions:ServiceCode"];
                var authBase = config["DevAPI:IdentityBaseURL"];
                _authURL = $"{authBase}ValidatePermission";
            }

            string bearerToken = _context.Request.Headers["Authorization"];
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = AuthenticationHeaderValue.Parse(bearerToken);

                var result = client.GetAsync($"{_authURL}?serviceCode={_serviceCode}&subServiceCode={process}&screenCode={subProcess}").Result;
                if (result.StatusCode == HttpStatusCode.Forbidden)
                {
                    var accessRights = JToken.Parse(result.Content.ReadAsStringAsync().Result);
                    var hasPermission = (accessRights.SelectToken("success") ?? JValue.CreateNull()).ToObject<bool?>();
                    if ((!hasPermission.GetValueOrDefault()))
                        return false;
                }
                else if (!result.IsSuccessStatusCode)
                {
                    throw new Exception("Permission validation failed.");
                }
            }
            return true;
        }
    }
}