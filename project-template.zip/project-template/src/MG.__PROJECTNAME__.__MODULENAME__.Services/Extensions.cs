﻿using System.Net.Http;
using System.Text;
using Newtonsoft.Json;

namespace MG.__PROJECTNAME__.__MODULENAME__.Services
{
    public static class Extensions
    {
        public static StringContent ToJsonStringContent(this object obj)
        {
            return new StringContent(JsonConvert.SerializeObject(obj),Encoding.UTF8,"application/json");
        }
    }
}